"""
URL configuration for Portal project.

Este archivo define las rutas principales de la aplicación Django.
Permite enrutar URLs hacia vistas específicas de tus apps (`usuarios`, `Pedidos`, etc.)
y hacia el panel de administración.

Documentación oficial:
https://docs.djangoproject.com/en/5.2/topics/http/urls/
"""

from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # 🔄 Redirección raíz e /inicio a la vista home (en Pedidos)
    path('', lambda request: redirect('home')),
    path('inicio/', lambda request: redirect('home')),

    # 🔐 Panel de administración
    path('admin/', admin.site.urls),
    path('base_datos/', lambda request: redirect('/admin/'), name='base_datos'),

    # 👥 Rutas de usuarios
    path('usuarios/', include('Apps.usuarios.urls')),

    # 📦 App Pedidos
    path('pedidos/', include('Apps.Pedidos.urls')),
    path('ajax/', include('Apps.Pedidos.urls_ajax')),

    # Indicadores
    path('indicadores/', include('Apps.indicadores.urls')),

    # Registros
    path('registro/', include('Apps.observaciones.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)