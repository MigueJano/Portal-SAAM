"""
ASGI config for Portal project.

Este archivo expone el objeto `application` que será usado por servidores
compatibles con ASGI (como Daphne, Uvicorn o Hypercorn) para ejecutar el proyecto.

ASGI es una especificación que permite manejar tráfico HTTP y protocolos asíncronos
como WebSockets en entornos Django.

Más información:
https://docs.djangoproject.com/en/5.2/howto/deployment/asgi/
"""

import os

# Importa la función que crea la instancia ASGI de la aplicación Django
from django.core.asgi import get_asgi_application

# Establece la configuración predeterminada del proyecto Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'Portal.settings')

# Crea la aplicación ASGI que será utilizada por el servidor asíncrono
application = get_asgi_application()
