"""
Django settings for Portal project.

Este archivo contiene la configuración principal del proyecto Django.
Incluye definición de aplicaciones instaladas, middleware, base de datos,
configuración de archivos estáticos, seguridad, internacionalización, y autenticación.

Generado por 'django-admin startproject' usando Django 5.2.4.

Documentación oficial:
- https://docs.djangoproject.com/en/5.2/topics/settings/
- https://docs.djangoproject.com/en/5.2/ref/settings/
"""

from pathlib import Path
import os

# 📁 Directorio base del proyecto
BASE_DIR = Path(__file__).resolve().parent.parent


# 🚨 Configuración de desarrollo (NO usar en producción)
SECRET_KEY = os.environ.get("SECRET_KEY")
DEBUG = os.environ.get("DEBUG", "False") == "True"
ALLOWED_HOSTS = ["saamspa.pythonanywhere.com", "127.0.0.1", "localhost"]

# 🔐 Redirección al cerrar sesión
LOGOUT_REDIRECT_URL = 'login'

CSRF_TRUSTED_ORIGINS = ["https://saamspa.pythonanywhere.com"]

# Seguridad en producción
SECURE_SSL_REDIRECT = True                     # Fuerza HTTPS
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
CSRF_COOKIE_SAMESITE = "Lax"
SECURE_HSTS_SECONDS = 31536000                 # 1 año
SECURE_HSTS_INCLUDE_SUBDOMAINS = False         # No usas subdominios propios
SECURE_HSTS_PRELOAD = False
SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"
X_FRAME_OPTIONS = "DENY"

# 🧱 Aplicaciones instaladas
INSTALLED_APPS = [
    # Apps core de Django
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',  # Para filtros como intcomma, naturaltime, etc.

    # Apps del proyecto
    'Apps.Pedidos',
    'Apps.usuarios',
    'Apps.indicadores',
    'Apps.observaciones',
]

# 🔁 Middleware HTTP
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# 🔗 Módulo de configuración de rutas principales
ROOT_URLCONF = 'Portal.urls'

# 🎨 Configuración de plantillas (HTML)
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],  # Puedes agregar rutas personalizadas si usas templates fuera de las apps
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# 🚪 WSGI (para despliegue con servidores compatibles como gunicorn)
WSGI_APPLICATION = 'Portal.wsgi.application'


# 🗃️ Base de datos SQLite (ideal para desarrollo)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'Database' / 'SAAM.db',  # Base de datos ubicada en carpeta /Database
    }
}


# 🔐 Validación de contraseñas
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]


# 🌎 Internacionalización
LANGUAGE_CODE = 'es-cl'  # Español de Chile
TIME_ZONE = 'America/Santiago'
USE_I18N = True
USE_L10N = True
USE_TZ = True


# 📦 Archivos estáticos (JS, CSS, imágenes de frontend)
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')  # Usado para producción (collectstatic)

# Directorios adicionales donde buscar archivos estáticos (útil en desarrollo)
STATICFILES_DIRS = [
    os.path.join(BASE_DIR, 'Apps/usuarios/static'),
    os.path.join(BASE_DIR, 'Apps/pedidos/static'),
    os.path.join(BASE_DIR, 'Apps/indicadores/static'),
]


# 📁 Archivos subidos por los usuarios
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')


# 🆔 Tipo de clave primaria por defecto
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'


# 🔐 Configuración de login/logout
LOGIN_URL = 'login'  # Ruta que redirige cuando se necesita autenticación
LOGIN_REDIRECT_URL = '/inicio/'  # Ruta destino luego de iniciar sesión exitosamente
