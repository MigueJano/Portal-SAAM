from django.db import migrations

SQL_CREATE_PREDET = r"""
CREATE TABLE IF NOT EXISTS "Pedidos_listapreciospredeterminada" (
    "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
    "nombre_listaprecios" varchar(80) NOT NULL UNIQUE,
    "descripcion_listaprecios" varchar(200) NOT NULL,
    "activa" bool NOT NULL,
    "creado" datetime NOT NULL,
    "actualizado" datetime NOT NULL
);
"""

SQL_CREATE_PREDET_ITEM = r"""
CREATE TABLE IF NOT EXISTS "Pedidos_listapreciospreditem" (
    "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
    "empaque" varchar(15) NOT NULL,
    "precio_venta" decimal NOT NULL,
    "precio_iva" decimal NOT NULL,
    "precio_total" decimal NOT NULL,
    "vigencia" date NOT NULL,
    "creado" datetime NOT NULL,
    "actualizado" datetime NOT NULL,
    "listaprecios_id" bigint NOT NULL REFERENCES "Pedidos_listapreciospredeterminada" ("id") DEFERRABLE INITIALLY DEFERRED,
    "nombre_producto_id" bigint NOT NULL REFERENCES "Pedidos_producto" ("id") DEFERRABLE INITIALLY DEFERRED,
    CONSTRAINT "uniq_pred_lista_producto_empaque" UNIQUE ("listaprecios_id", "nombre_producto_id", "empaque")
);
"""

class Migration(migrations.Migration):

    dependencies = [
        ('Pedidos', '0001_initial'),
    ]

    operations = [
        migrations.RunSQL(
            SQL_CREATE_PREDET,
            reverse_sql='DROP TABLE IF EXISTS "Pedidos_listapreciospredeterminada";'
        ),
        migrations.RunSQL(
            SQL_CREATE_PREDET_ITEM,
            reverse_sql='DROP TABLE IF EXISTS "Pedidos_listapreciospreditem";'
        ),
    ]
